/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservapistasconbeans;

import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JTextField;

/**
 *
 * @author diego
 */
public class BBDDReservas {
    
    public BBDDReservas(){
    }
    
    public void Connection(){
        System.out.println("La conexion con la base de datos se ha realizado"
                + "correctamente");
    }
    
    public boolean addReserva(JTextField nombre, JTextField telefono, JSpinner fecha, JComboBox hora){
        System.out.println("Se ha añadido correctamente su reserva");
        return true;
    }

    
}