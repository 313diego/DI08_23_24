/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package reservapistasconbeans;

import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.SwingUtilities;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author diego
 */
public class PantallaPrincipalTest {
    
    static PantallaPrincipal pantallaPrincipal = new PantallaPrincipal();
    
    public PantallaPrincipalTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                pantallaPrincipal = new PantallaPrincipal();
            }
        });
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getMenuItemAyuda method, of class PantallaPrincipal.
     */
    @Test
    public void testGetMenuItemAyuda() {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                System.out.println("Test MenuItemAyuda");
                pantallaPrincipal.getMenuItemAyuda();
                JRadioButtonMenuItem menuItemAyuda = pantallaPrincipal.getMenuItemAyuda();
                assertTrue(menuItemAyuda.isSelected());
            }
        });        
    }

    /**
     * Test of getMenuItemNuevaReserva method, of class PantallaPrincipal.
     */
    @Test
    public void testGetMenuItemNuevaReserva() {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                System.out.println("Test MenuItemNuevaReserva");
                pantallaPrincipal.getMenuItemNuevaReserva();
                JRadioButtonMenuItem menuItemNuevaReserva = pantallaPrincipal.getMenuItemNuevaReserva();
                assertTrue(menuItemNuevaReserva.isSelected());
            }
        });  
    }

    /**
     * Test of getMenuItemSalir method, of class PantallaPrincipal.
     */
    @Test
    public void testGetMenuItemSalir() {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                System.out.println("Test MenuItemSalir");
                pantallaPrincipal.getMenuItemSalir();
                JRadioButtonMenuItem menuItemSalir = pantallaPrincipal.getMenuItemSalir();
                assertTrue(menuItemSalir.isSelected());
            }
        });  
    }

    /**
     * Test of getBtNuevaReservaP method, of class PantallaPrincipal.
     */
    @Test
    public void testGetBtNuevaReservaP() {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                System.out.println("Test BtNuevaReservaP");
                pantallaPrincipal.getBtNuevaReservaP();
                JButton BtNuevaReservaP = pantallaPrincipal.getBtNuevaReservaP();
                assertTrue(BtNuevaReservaP.isSelected());
            }
        });  
    }

    /**
     * Test of getBtSalirP method, of class PantallaPrincipal.
     */
    @Test
    public void testGetBtSalirP() {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                System.out.println("Test BtSalirP");
                pantallaPrincipal.getBtSalirP();
                JButton BtSalirP = pantallaPrincipal.getBtSalirP();
                assertTrue(BtSalirP.isSelected());
            }
        });  
    }

    /**
     * Test of getMenuAyuda method, of class PantallaPrincipal.
     */
    @Test
    public void testGetMenuAyuda() {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                System.out.println("Test MenuAyuda");
                pantallaPrincipal.getMenuAyuda();
                JMenu menuAyuda = pantallaPrincipal.getMenuAyuda();
                assertTrue(menuAyuda.isSelected());
            }
        });  
    }

    /**
     * Test of getMenuReservas method, of class PantallaPrincipal.
     */
    @Test
    public void testGetMenuReservas() {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                System.out.println("Test MenuReservas");
                pantallaPrincipal.getMenuReservas();
                JMenu menuReservas = pantallaPrincipal.getMenuReservas();
                assertTrue(menuReservas.isSelected());
            }
        });  
    }

    /**
     * Test of getMenuSalir method, of class PantallaPrincipal.
     */
    @Test
    public void testGetMenuSalir() {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                System.out.println("Test MenuSalir");
                pantallaPrincipal.getMenuSalir();
                JMenu menuSalir = pantallaPrincipal.getMenuSalir();
                assertTrue(menuSalir.isSelected());
            }
        });  
    }

    /**
     * Test of main method, of class PantallaPrincipal.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        PantallaPrincipal.main(args);
    }
    
}
