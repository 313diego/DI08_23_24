/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package reservapistasconbeans;

import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.SwingUtilities;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.mockito.Mock;
import org.mockito.Mockito;

/**
 *
 * @author diego
 */
public class DialogoReservasTest {
    
    @Mock
    static DialogoReservas dialogoReservas;

    public DialogoReservasTest() {
    }

    @BeforeClass
    public static void setUpClass() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                dialogoReservas = new DialogoReservas(new JFrame(), true);
            }
        });
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getButtonEnviar method, of class DialogoReservas.
     */
    @Test
    public void testGetButtonEnviar() {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                // Probamos el boton con JUnit
                System.out.println("Test ButtonEnviar");
                dialogoReservas.getButtonEnviar();
                JButton btEnviar = dialogoReservas.getButtonEnviar();
                assertTrue(btEnviar.isSelected());
                
                //Accedemos a los campos de nombre, prefijo y teléfono
                JTextField nombre = dialogoReservas.getTextNombre();
                JTextField prefijo = dialogoReservas.getTextFieldPrefijo();
                JTextField telefono = dialogoReservas.getTextFieldTelefono();
                // Establecemos el nombre, teléfono y prefijo
                nombre.setText("Diego Carrasco");
                prefijo.setText("+34");
                telefono.setText("666111222");
                //Accedemos al spinner de la fecha y obtenemos el módelo
                JSpinner fecha = dialogoReservas.getSpinnerFechaReserva();
                SpinnerDateModel modelo = (SpinnerDateModel) fecha.getModel();
                //Establecemos la fecha actual al spinner
                modelo.setValue(new Date());
                //Accedemos al combobox de la hora de la reserva
                JComboBox hora = dialogoReservas.getComboBoxHoraReserva();
                //Obtenemos el modelo
                DefaultComboBoxModel modeloHora = new DefaultComboBoxModel();
                hora.setModel(modeloHora);
                //Establecdemos la hora de la reserva
                hora.setSelectedItem("17:00");
                //Creamos el mock para la base de datos.
                BBDDReservas mockBase = Mockito.mock(BBDDReservas.class);
                Mockito.verify(mockBase).Connection();
                Mockito.when(mockBase.addReserva(nombre, telefono, fecha, hora)).thenReturn(true);
            }
        }); 
    }

    /**
     * Test of getButtonVolver method, of class DialogoReservas.
     */
    @Test
    public void testGetButtonVolver() {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                System.out.println("Test ButtonVolver");
                dialogoReservas.getButtonVolver();
                JButton btVolver = dialogoReservas.getButtonVolver();
                assertTrue(btVolver.isSelected());
            }
        }); 
    }

    /**
     * Test of getjButtonAyuda method, of class DialogoReservas.
     */
    @Test
    public void testGetjButtonAyuda() {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                System.out.println("Test ButtonAyuda");
                dialogoReservas.getjButtonAyuda();
                JButton jbtAyuda = dialogoReservas.getjButtonAyuda();
                assertTrue(jbtAyuda.isSelected());
            }
        }); 
    }
    
}
